# terraform-aws

Terraform files for AWS cloud.

## Mandatory: submit merge requests for a protected branch

**IMPORTANT**: All changes must be made by submitting a merge request, rather than check in directly to a protected branch.

## Branch Naming Conventions

Naming your branch according to the following two categories:

- Code Flow Branches (Protected Branches)
    - master
    - release/77.0.0
    - dev/k8s
- Temporary Branches
    - feature/OPS-8888_send-ses-event-to-es -> For new features.
    - m/OPS-9999_xxxx -> m stands for Modification, for modification on existing resources.

For details, please see [this](https://dev.to/couchcamote/git-branching-name-convention-cch).

## Required AWS profile settings.

Terraform state files for all environments are stored in the S3 bucket under the **arena-main** account, so you must ensure that a profile with the name **main** exists in your ~/.aws folder, otherwise running the `atf` command will fail.

Also, you need to make sure the **main** AWS profile has been activated before running the `atf` command each time.

To Activate your **arena-main** AWS MFA session.

1. Get the scripts used for AWS MFA authentication

```bash
git clone https://git.dev.bom.com/webops/aws-scripts.git
```

2. Activate

```bash
pushd aws-scripts 
./aws-mfa-auth --print main <Google Authenticator token> 
popd
```

## Required environment variables for atf script.

Bash
```bash
export WORKING_DIR_TERRAFORM="${PWD}"
export PATH=${WORKING_DIR_TERRAFORM}/bin:${PATH}

read -p "TARGET_ENV=" TARGET_ENV && export TARGET_ENV; read -p "AWS_PROFILE=" AWS_PROFILE && export AWS_PROFILE && export TF_VAR_aws_profile=${AWS_PROFILE}
```

Zsh
```shell
export WORKING_DIR_TERRAFORM="${PWD}"
export PATH=${WORKING_DIR_TERRAFORM}/bin:${PATH}

read "TARGET_ENV?TARGET_ENV=" && export TARGET_ENV; read "AWS_PROFILE?AWS_PROFILE=" && export AWS_PROFILE && export TF_VAR_aws_profile=${AWS_PROFILE}
```

