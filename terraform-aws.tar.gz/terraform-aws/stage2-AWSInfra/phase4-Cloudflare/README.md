## Cloudflare

### Explanation:
> This phase is related to the Cloudflare. If var.cloudflare_enable is set
> as true, then the lambda and its resources would be created, which is 
> responsible to update the security group to allow the access from Cloudflare
> with URL https://api.cloudflare.com/client/v4/ips. The interval is 24
> hours to call Cloudflare api to get whitelisted ipv4/ipv6 address to update 
> the security group.


### Resources
- access
  - aws_iam_role
  - aws_iam_policy
  - aws_iam_policy_attachment
- handler
  - aws_lambda_function
- trigger
  - aws_cloudwatch_event_rule
  - aws_cloudwatch_event_target
  - aws_lambda_permission
- resource
  - aws_security_group




