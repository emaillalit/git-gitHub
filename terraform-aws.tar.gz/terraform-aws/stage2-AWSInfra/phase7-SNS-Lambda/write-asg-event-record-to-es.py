import json
import os
import time
import datetime
import pymsteams
import requests
import charset_normalizer
import certifi
from es.elasticsearch import Elasticsearch


def write_to_es(doc):
    # set es address accorind to the env name
    aws_env = os.environ["ENV"]
    es_address = ["es01.util.aws.bom.com", "es02.util.aws.bom.com", "es03.util.aws.bom.com"]
    if aws_env == "arenagov":
        es_address = ["es01.util.arenagov.com", "es02.util.arenagov.com", "es03.util.arenagov.com"]

    es = Elasticsearch(es_address, ssl_show_warn=False)

    es_index_key_name = os.environ["ES_INDEX_KEY_NAME"]
    now = datetime.datetime.utcnow()
    index_name = '%s-%s-%d.%02d.%02d' % (aws_env, es_index_key_name, now.year, now.month, now.day)
    epoch_nano = time.time_ns()
    doc["@timestamp"] = now
    res = es.index(index=index_name, id=epoch_nano, body=doc)
    return res


def send_alert(event):
    # AlertManager General Channel
    WebHookURL = "https://ptccloud.webhook.office.com/webhookb2/71ea2cf3-989e-4f75-8d23-876215dd7d90@b9921086-ff77-4d0d-828a-cb3381f678e2/IncomingWebhook/9292bf5ef6134f04ad8fcf0828d2f6e1/a946d16b-8b73-4615-bf0c-c398cb23b1a3"
    # tutorial Channel
    #WebHookURL = "https://ptccloud.webhook.office.com/webhookb2/537e05ea-5cdd-46f0-8226-6683075dc214@b9921086-ff77-4d0d-828a-cb3381f678e2/IncomingWebhook/103a67fa2256441684129519ec74cef4/a946d16b-8b73-4615-bf0c-c398cb23b1a3"

    # You must create the connectorcard object with the Microsoft Webhook URL
    myTeamsMessage = pymsteams.connectorcard(WebHookURL)
    # Add text to the message.
    myTeamsMessage.title("AWS AutoScaleGroup Alert")
    myTeamsMessage.summary(" ")
    #myTeamsMessage.addLinkButton("link for detail", "https://github.com/rveachkc/pymsteams/")
    myTeamsMessage.color("FF000F")
    # create the section
    MessageSection = pymsteams.cardsection()
    record = event.get("Records")[0]
    # Facts are key value pairs displayed in a list.
    msgList = ["Subject", "Type", "Event", "Description", "StatusCode", "AutoScalingGroupName", "EC2InstanceId", "StartTime", "EndTime", "Cause", "AutoScalingGroupARN", "UnsubscribeUrl"]
    msgMap = {}
    for k, v in record.get("Sns").items():
        if k == "Message":
            for ik, iv in v.items():
                if ik in msgList:
                    msgMap[ik] = iv
        if k in msgList:
            msgMap[k] = v

    for k in msgList:
        MessageSection.addFact(k, msgMap[k])

    # Add your section to the connector card object before sending
    myTeamsMessage.addSection(MessageSection)
    # send the message.
    myTeamsMessage.send()


def lambda_handler(event, context):
    send_alert(event)
    print("--> Handling SNS sending event record")
    print("Current UTC time is: ", datetime.datetime.utcnow())
    print(event)

    msg = event.get("Records")[0].get("Sns").get("Message")
    msg_dict = json.loads(msg)
    res = write_to_es(msg_dict)
    print(res)
