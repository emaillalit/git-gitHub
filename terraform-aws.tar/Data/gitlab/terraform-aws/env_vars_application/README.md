---
### Explaination of parameters
#### There are several parameters in terraform-aws/env_vars_application/*.tfvars are not explicitly explained the purpose, here we explain them.


---
#### aws_account-is_production

###### for terraform repository
- if false, GROUP-Developers.tf file
```shell
resource "aws_iam_group_policy_attachment" "attach-Developers-ec2-full-access" {
  count      = var.aws_account-is_production == true ? 0 : 1
  group      = aws_iam_group.group-Developers.name
  policy_arn = "${var.aws_arn_prefix}:iam::aws:policy/AmazonEC2FullAccess"
}

```

---
#### is_production

###### for terraform repository
- if true, you can not destroy terraform resources with atf

- if true, check_instance_readyness script would check the fixer service
```shell
for svc in ${svc_list}; do
	[[ ${svc} == "fixer" ]] && [[ ${IS_PRODUCTION} == "yes" ]] && continue
	echo "${svc}"
	check_image_tag ${svc}
	check_db_password ${svc}
	check_pki ${svc}
done
```

- if true, postprocessing script 
```shell
# Main
if [[ "${IS_PRODUCTION}" == "yes" ]]; then
  create_files_repo_replication_destination_s3_bucket
  render_replication_json
  create_bucket_replication
else
  delete_bucket_replication
fi
```

- if true, prepare script would 
```shell
  if [[ "${IS_PRODUCTION}" == "yes" ]]; then
    echo "-> Enable versioning for S3 bucket ${FILES_REPO_BUCKET}"
    ${AWSCLI} s3api put-bucket-versioning --bucket "${FILES_REPO_BUCKET}" --versioning-configuration Status="Enabled" > /dev/null
    echo
    echo "-> Enable encryption for S3 bucket ${FILES_REPO_BUCKET}"
    ${AWSCLI} s3api put-bucket-encryption --bucket "${FILES_REPO_BUCKET}" --server-side-encryption-configuration file://json-data/s3-encryption.json > /dev/null
    echo
    echo "-> Create lifecycle rules for S3 bucket ${FILES_REPO_BUCKET}"
    ${AWSCLI} s3api put-bucket-lifecycle-configuration --bucket "${FILES_REPO_BUCKET}" --lifecycle-configuration file://json-data/s3-lifecycle.json > /dev/null
    echo
```
- if false, would create
  - fixer internal elb cname
  - fixer elb
  - fixer launch configuration
  - fixer asg
- if true, gate.tf file
  - gate-lb security_groups = var.cloudflare_enable == true ? data.aws_security_groups.cloudflare_http_https.ids : var.is_production == true ? data.aws_security_groups.public_http_https.ids : data.aws_security_groups.arena_subnets_http_https.ids
- if true, plm.tf file
  - plm-lb security_groups = var.cloudflare_enable == true ? data.aws_security_groups.cloudflare_http_https.ids : var.is_production == true ? data.aws_security_groups.public_http_https.ids : data.aws_security_groups.arena_subnets_http_https.ids

###### for ansible repository
- if true, tag-role-render.go would change below
```shell
    checkIfProduction = "1"
    emailSubjectPrepend = ""
    emailRcptDomainsAllowed = ""
    emailSenderEmployeesAllowed = ""
    featureTfaDisable = "false"
    marketingSite = "arena-marketing.arenasolutions.com"
    enableLanguageSetting = "Off"
    applicationMonitoringEmail = "arena-app-monitor@ptc.com"
    databaseMonitoringEmail = "arena-db-monitor@ptc.com"
```
- if true, tag_Role_template_
  - acct RUNMODE_ACTIVE: "<<.IsProd>>"
  - notify PRODUCTION: "<<.IsProd>>"
  - notify  RUNMODE_ACTIVE: "<<.IsProd>>"
  - orca  RUNMODE_ACTIVE: "<<.IsProd>>"
  - xray  RUNMODE_ACTIVE: "<<.IsProd>>"
- if true, prompt command would be like 
```shell
export PROMPT_COMMAND='export PS1="[(\e[31;1mArenaProd-{{ env_context }}\e[0m) \u@\h:\l \W]\\$ "'

```
- if false, postfix.yml would copy recipient access and run recipient postmap
```shell
- name: copy recipient_access
  ansible.builtin.copy:
    src: recipient_access
    dest: /etc/postfix/recipient_access
  when: is_production == 'false'
  
- name: run recipient postmap
  ansible.builtin.command: postmap /etc/postfix/recipient_access
  when: is_production == 'false'  
```
- if false, main.cr.j2 file would
```shell
{% if is_production == 'false' %}
# Restrict recipient domain.
smtpd_recipient_restrictions = check_recipient_access hash:/etc/postfix/recipient_access, reject

{% endif %}
```

---
#### cloudflare_enable

###### for terraform repository
- if true, gate.tf file
  - public_alb_cname_api  records  = [var.cloudflare_enable == true ? "api.${var.base_domain_name}.cdn.cloudflare.net" : aws_lb.gate_lb.dns_name]
  - public_alb_cname_apps   records  = [var.cloudflare_enable == true ? "apps.${var.base_domain_name}.cdn.cloudflare.net" : aws_lb.gate_lb.dns_name]
  - public_alb_cname_files   records  = [var.cloudflare_enable == true ? "files.${var.base_domain_name}.cdn.cloudflare.net" : aws_lb.gate_lb.dns_name]
  - gate load balancer   security_groups    = var.cloudflare_enable == true ? data.aws_security_groups.cloudflare_http_https.ids : var.is_production == true ? data.aws_security_groups.public_http_https.ids : data.aws_security_groups.arena_subnets_http_https.ids
- if true, phase4-Cloudflare/lambda.tf file
  - cloudflare-lambda-role
  - cloudflare-lambda-policy
  - attach-cloudflare-policy
  - cloudflare-lambda_function  count = var.cloudflare_enable == true ? 1 : 0
  - lambda_trigger_rule   count = var.cloudflare_enable == true ? 1 : 0
  - lambda_trigger_target   count = var.cloudflare_enable == true ? 1 : 0
  - allow_daily_trigger count = var.cloudflare_enable == true ? 1 : 0
- if true, phase4-Cloudflare/security-group.tf file
  - cloudflare_http_https var.cloudflare_enable == true ? 1 : 0
- if true, plm.tf file
  - plm_public_alb_cname   records  = [var.cloudflare_enable == true ? "app.${var.base_domain_name}.cdn.cloudflare.net" : aws_lb.plm_lb.dns_name]
  - plm_lb   security_groups = var.cloudflare_enable == true ? data.aws_security_groups.cloudflare_http_https.ids : var.is_production == true ? data.aws_security_groups.public_http_https.ids : data.aws_security_groups.arena_subnets_http_https.ids
  

---
#### syslog_enable 

###### for ansible repository
- if true, deploy-c14n-pod.yml
```shell
---
- hosts: 'tag_Role_{{ role }}'
  roles:
    - role: common
    - role: ssh-connection
      tags: ssh
    - role: mount-storagegateway
      when: ec2_tag_ServiceName == 'gate'
      tags:
        - mount-storage-gateway
    - role: deploy-c14n-pod
    - role: deploy-metrics-agent
      when: service_status.stdout.find("success") != -1
      tags:
        - metrics-agent
    - role: deploy-syslog-forwarding
      when: syslog_enable == "true"
    - role: deploy-tmds-agent
      tags:
        - tmds-agent

```
- if true, fluent-but.conf
```shell
{% if syslog_enable == "true" %}
[OUTPUT]
    name                 syslog
    match                *
    host                 syslog.aws.bom.com
    port                 514
    mode                 tcp
    syslog_format        rfc5424
    syslog_maxsize       2048
    syslog_severity_key  severity
    syslog_facility_key  facility
    syslog_hostname_key  hostname
    syslog_appname_key   appname
    syslog_procid_key    procid
    syslog_msgid_key     msgid
    syslog_sd_key        sd
    syslog_message_key   log
{% endif %}
```

- if true, ARENA-syslog-forwarding.conf.j2
```shell
{% if base_domain_name == "arenagov.com" %}
# Arena customized configuration.
#
# audit log
$ModLoad imfile
$InputFileName /var/log/audit/audit.log
$InputFileTag AUDIT_LOG:
$InputFileStateFile audit_log
$InputFileSeverity info
$InputFileFacility local6
$InputRunFileMonitor
local6.* @@syslog-agent-audit.util.arenagov.com
# All logs other than Audit logs.
*.*,local6.none @@syslog-agent-system.util.arenagov.com

{% else %}
$PreserveFQDN on
*.* @@syslog.util.aws.bom.com:514

{% endif %}

```

---
##### use_import_cert 

###### for terraform repository
- if true, admin.f
  - admin_lb_listener   certificate_arn = var.use_import_cert == true ? data.aws_acm_certificate.imported_admin[0].arn : data.aws_acm_certificate.nonpublic[0].arn
- if true, auth.tf
  - auth_lb_listener   certificate_arn = var.use_import_cert == true ? data.aws_acm_certificate.imported_auth[0].arn : data.aws_acm_certificate.nonpublic[0].arn
- if true, stage4-Application/data.tf
```shell
data "aws_acm_certificate" "public" {
  count    = var.use_import_cert == false ? 1 : 0
  domain   = "app.${var.base_domain_name}"
  statuses = ["ISSUED"]
  types    = ["AMAZON_ISSUED"]
}

data "aws_acm_certificate" "nonpublic" {
  count    = var.use_import_cert == false ? 1 : 0
  domain   = "admin.${var.base_domain_name}"
  statuses = ["ISSUED"]
  types    = ["AMAZON_ISSUED"]
}

data "aws_acm_certificate" "imported_public" {
  count    = var.use_import_cert == true ? 1 : 0
  domain   = "api.${var.base_domain_name}"
  statuses = ["ISSUED"]
  types    = ["IMPORTED"]
}

data "aws_acm_certificate" "imported_admin" {
  count    = var.use_import_cert == true ? 1 : 0
  domain   = "admin.${var.base_domain_name}"
  statuses = ["ISSUED"]
  types    = ["IMPORTED"]
}

data "aws_acm_certificate" "imported_auth" {
  count    = var.use_import_cert == true ? 1 : 0
  domain   = "auth.${var.base_domain_name}"
  statuses = ["ISSUED"]
  types    = ["IMPORTED"]
}
```

- if true, gate.tf file
  - gate_lb_listener   certificate_arn = var.use_import_cert == true ? data.aws_acm_certificate.imported_public[0].arn : data.aws_acm_certificate.public[0].arn

- if true, plm.tf file
  - plm_lb_listener  certificate_arn = var.use_import_cert == true ? data.aws_acm_certificate.imported_public[0].arn : data.aws_acm_certificate.public[0].arn


---
##### use_import_cert 

###### for terraform repository
- phase3-Route53-ACM-S3/provider.tf would use another profiler
- phase2-Bastion-Redis-RabbitMQ-Mail-Backtop/main.tf file 
- phase5-Metrics/provider.tf
- stage4-Application/provider.tf

```shell
# Set for public DNS zone in case of using remote dns (Route53 in another AWS account)
provider "aws" {
  alias   = "aws-dns"
  profile = var.use_remote_dns == true ? var.aws_profile_dns : var.aws_profile
  region  = var.use_remote_dns == true ? var.aws_region_dns : var.aws_region
}
```


