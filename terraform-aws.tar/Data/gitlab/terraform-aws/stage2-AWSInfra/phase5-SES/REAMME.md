### Description
1. Create AWS SES verified identity and configuration set.
2. Set SES sending event destination to SNS, register Lambda function as subscription.
3. In Lambda function, write the SES sending event records to arena-main Elasticsearch Utility.
4. Then we can search the SES sending event records in Kibana.

### Workflow
* AWS SES
    * Verified identity
    * Configuration set
        * Event destination ->
            * SNS ->
                * Lambda ->
                    * Elasticsearch ->
                        * Kibana

## Generate the zip file
```shell
zip -r send-ses-event-record-to-es.zip write-ses-event-record-to-es.py es
```

## Manual works
Terraform doesn't support assigning configuration set to verified identity, so after creating the configuration set, we must assign it manually.
