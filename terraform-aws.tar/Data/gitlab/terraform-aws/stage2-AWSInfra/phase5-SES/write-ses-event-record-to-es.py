import json
import os
import time
import datetime
from es.elasticsearch import Elasticsearch


def write_to_es(doc):
    # set es address according to the env name
    aws_env = os.environ["ENV"]
    es_address = ["es01.util.aws.bom.com", "es02.util.aws.bom.com", "es03.util.aws.bom.com"]
    if aws_env == "arenagov":
        es_address = ["es01.util.arenagov.com", "es02.util.arenagov.com", "es03.util.arenagov.com"]
    if aws_env == "arenaeurope" or aws_env == "awseuc":
        es_address = ["es01.eu.util.aws.bom.com", "es02.eu.util.aws.bom.com", "es03.eu.util.aws.bom.com"]
    es = Elasticsearch(es_address, ssl_show_warn=False)

    es_index_key_name = os.environ["ES_INDEX_KEY_NAME"]
    now = datetime.datetime.utcnow()
    index_name = '%s-%s-%d.%02d.%02d' % (aws_env, es_index_key_name, now.year, now.month, now.day)
    epoch_nano = time.time_ns()
    doc["@timestamp"] = now
    res = es.index(index=index_name, id=epoch_nano, body=doc)
    return res


def lambda_handler(event, context):
    print("--> Handling SES sending event record")
    print("Current UTC time is: ", datetime.datetime.utcnow())
    print(event)

    msg = event.get("Records")[0].get("Sns").get("Message")
    msg_dict = json.loads(msg)
    res = write_to_es(msg_dict)
    print(res)
