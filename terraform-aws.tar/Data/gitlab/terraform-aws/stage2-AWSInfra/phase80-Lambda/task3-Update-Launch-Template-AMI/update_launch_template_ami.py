import datetime
import os
import sys
import time
import boto3


class UpdateLaunchTemplateAMI:
    start_time = datetime.datetime.utcnow()

    def __init__(self, pipeline_name, environment):
        print("class AmiCiPipeline start at UTC time %s" % self.start_time)
        self.pipeline_name = pipeline_name
        self.environment = environment

        self.session = self.get_aws_session()
        self.ib = self.session.client('imagebuilder')
        self.asg = self.session.client('autoscaling')
        self.ec2 = self.session.client('ec2')

    def get_aws_session(self):
        # get the aws session per region
        region = os.getenv("REGION")
        if region is None:
            print("Please provide the aws running region as env variable REGION .")
            sys.exit(1)
        return boto3.Session(
            region_name=region,
        )

    def get_pipeline_arn_per_name(self):
        res = self.ib.list_image_pipelines()
        # get the pipeline arn according to the given pipeline name
        pipeline_arn = ""
        for p in res['imagePipelineList']:
            if p['name'] == self.pipeline_name:
                pipeline_arn = p['arn']
        if len(pipeline_arn) == 0:
            print("the provided pipeline not found")
            sys.exit(1)
        return pipeline_arn

    # def trigger_pipeline_build(self):
    #     pipeline_arn = self.get_pipeline_arn_per_name()
    #     # trigger the pipeline
    #     try:
    #         res = self.ib.start_image_pipeline_execution(imagePipelineArn=pipeline_arn)
    #     except Exception as e:
    #         print(e)
    #         sys.exit(1)
    #     return res["imageBuildVersionArn"]

    def get_latest_image_from_pipeline(self):
        pipeline_arn = self.get_pipeline_arn_per_name()
        out_images = []
        content = {
            "imagePipelineArn": pipeline_arn,
            'maxResults': 25,
        }
        running = True
        while running:
            res = self.ib.list_image_pipeline_images(**content)
            out_images.extend(res['imageSummaryList'])
            if res.get('nextToken') is None:
                running = False
            else:
                content['nextToken'] = res['nextToken']

        if len(out_images) == 0:
            print("There is no image already built for pipeline")
            sys.exit(1)

        latest_image = out_images[0]
        for i in range(1, len(out_images)):
            create_time_str = out_images[i]['dateCreated']
            time_format = "%Y-%m-%dT%H:%M:%S.%fZ"
            if datetime.datetime.strptime(out_images[i]['dateCreated'], time_format) > datetime.datetime.strptime(
                    latest_image['dateCreated'], time_format):
                latest_image = out_images[i]

        return latest_image

    def show_image_info(self, image_build_version_arn):
        res = self.ib.get_image(imageBuildVersionArn=image_build_version_arn)
        return res

    def is_image_build_version_complete(self, image_build_version_arn):
        # check the building image is completed
        status = self.show_image_info(image_build_version_arn)['image']['state']['status']
        print("the current image %s status is %s" % (image_build_version_arn, status))
        if status == "AVAILABLE":
            return True
        elif status in ["CANCELLED", "FAILED", "DEPRECATED", "DELETED"]:
            print("image current status is %s, so exit now" % status)
            exit(1)
        else:
            return False

    def list_asgs_per_env(self):
        asgs = []
        running = True
        content = {
            'MaxRecords': 100,
        }
        while running:
            res = self.asg.describe_auto_scaling_groups(**content)
            for a in res['AutoScalingGroups']:
                if str(a['AutoScalingGroupName']).startswith(self.environment):
                    asgs.append(a)
            next_token = res.get('NextToken')
            if next_token is not None:
                content['NextToken'] = next_token
            else:
                running = False

        return asgs

    def get_current_launch_template_latest_ami_id(self, template_id):
        res = self.ec2.describe_launch_template_versions(
            LaunchTemplateId=template_id,
            Versions=['$Latest'],
        )

        if len(res['LaunchTemplateVersions']) == 0:
            print("launch template %s has no version yet" % res['LaunchTemplateVersions'][0]['LaunchTemplateName'])
            sys.exit(1)

        return res['LaunchTemplateVersions'][0]['LaunchTemplateData']['ImageId']

    def update_launch_template_against_ami(self, launch_template_id, ami_id):
        content = {
            "LaunchTemplateData": {
                'ImageId': ami_id,
            },
            "LaunchTemplateId": launch_template_id,
            'SourceVersion': '$Latest',
        }
        res = self.ec2.create_launch_template_version(**content)
        if res['ResponseMetadata']['HTTPStatusCode'] == 200:
            return True
        else:
            return False

    def handle(self):
        # trigger the pipeline and get the new ami id
        # image_build_version_arn = self.trigger_pipeline_build()

        # get the latest image version from the pipeline
        latest_image_from_pipeline = self.get_latest_image_from_pipeline()
        # print(latest_image_from_pipeline)

        # make sure the image is available before proceed to update the launch template
        while not self.is_image_build_version_complete(latest_image_from_pipeline['arn']):
            now = datetime.datetime.utcnow()
            if now - self.start_time > datetime.timedelta(seconds=600):
                print("from the job execute, the duration is over 600 seconds, so stop here")
                sys.exit(1)
            time.sleep(60)
            print("wait 60 seconds and see the status of the build %s" % latest_image_from_pipeline)
        print("validated that ami %s is good for updating launch template ." % latest_image_from_pipeline['arn'])

        # get the ami of the image build in current aws region
        latest_ami_id_from_pipeline = ""
        for ami in latest_image_from_pipeline['outputResources']['amis']:
            if ami['region'] == self.session.region_name:
                latest_ami_id_from_pipeline = ami['image']

        # update the launch template of asgs
        asgs = self.list_asgs_per_env()
        for asg in asgs:
            asg_name = asg['AutoScalingGroupName']
            launch_template = asg.get('LaunchTemplate')
            # only update the asg using launch template
            if launch_template is None:
                print("asg %s is not using launch template" % asg_name)
            else:
                launch_template_id = launch_template['LaunchTemplateId']
                current_launch_template_ami = self.get_current_launch_template_latest_ami_id(launch_template_id)
                # only update the launch template if the latest pipeline ami differ from launch template ami id
                if latest_ami_id_from_pipeline == current_launch_template_ami:
                    print("latest pipeline ami %s is same as latest launch template ami %s, no need to update %s LT"
                          % (latest_ami_id_from_pipeline, current_launch_template_ami, asg_name))
                else:
                    if self.update_launch_template_against_ami(launch_template_id, latest_ami_id_from_pipeline):
                        print("ASG %s launch template has been updated with new ami %s" % (
                            asg_name, latest_ami_id_from_pipeline))
                    else:
                        print("ASG %s launch template failed to be updated with ami %s" % (
                            asg_name, latest_ami_id_from_pipeline))


def lambda_handler(event, context):
    # get key info from env
    pipeline = os.getenv("PIPELINE_NAME")
    if pipeline is None:
        print("Please provide the ec2 image builder pipeline name as env variable PIPELINE_NAME .")
        sys.exit(1)
    env = os.getenv("ENVIRONMENT")
    if env is None:
        print("Please provide the aws running region as env variable ENVIRONMENT .")
        sys.exit(1)

    print(event)
    source = event.get("source")
    detail_type = event.get("detail-type")
    # trigger by cronjob
    if source == "aws.events" and detail_type == "Scheduled Event":
        print("lambda triggered by aws scheduled events.")
    # trigger by the event bus call
    elif source == "com.bom.ami" and detail_type == "ImageBuilder.UpdateLaunchTemplate":
        if env != event.get('detail').get('env'):
            print("the env passed from the event bus not matching current lambda env from variable")
            sys.exit(1)
        print("lambda triggered by the event bus to update launch template.")
    else:
        print("trigger currently not supported.")
        sys.exit(1)

    update_launch_template_ami = UpdateLaunchTemplateAMI(pipeline_name=pipeline, environment=env)
    update_launch_template_ami.handle()
