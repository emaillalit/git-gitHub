To terraform plan/apply these resources, you have to complete the arena-main MFA authentication.

### Config AWS profile 'main'
Following the steps in below link to config your AWS profile 'main'

https://arenasolutions.atlassian.net/wiki/spaces/DEVOPS/pages/1472529800/Workspace+setup+for+deploying+to+AWS+environments#Set-up-AWS-CLI

### Activate your AWS MFA session

1. Get the scripts used for AWS MFA authentication.
```
cd $HOME/aws-cd
git clone https://git.dev.bom.com/zwei/aws-scripts.git
```
2. Activate
```
pushd $HOME/aws-cd/aws-scripts
./aws-mfa-auth --print main <Google Authenticator token>
popd
```