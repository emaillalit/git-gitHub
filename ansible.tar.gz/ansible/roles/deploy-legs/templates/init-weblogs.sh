#!/bin/bash

export AWS_DEFAULT_REGION={{ aws_region }}

mkdir -p ~/.ssh
chmod 700 ~/.ssh

aws s3 cp s3://legs.{{ aws_region }}.{{ aws_account_id }}/legs ~/.ssh/legs
chmod 400 ~/.ssh/legs

LEGS_SSH_KEY_ID=$(aws iam list-ssh-public-keys --user-name APP-gitlab-to-aws-legs --query "SSHPublicKeys[*].SSHPublicKeyId" --output text)

cat <<EOF > /home/ARENA/weblogs/.ssh/config
Host git-codecommit.*.amazonaws.com
User $LEGS_SSH_KEY_ID
IdentityFile ~/.ssh/legs
StrictHostKeyChecking no
EOF

chmod 600 ~/.ssh/config

ssh-keyscan git-codecommit.{{ aws_region }}.amazonaws.com >> ~/.ssh/known_hosts

chown weblogs -R /home/ARENA/weblogs

if [[ -d "$HOME/legs" ]]; then
    cd $HOME/legs
    git status
    [[ "$?" -ne 0 ]] && rm -rf ~/legs && cd ~ && git clone ssh://git-codecommit.{{ aws_region }}.amazonaws.com/v1/repos/legs
  else
    cd ~ && git clone ssh://git-codecommit.{{ aws_region }}.amazonaws.com/v1/repos/legs
fi
