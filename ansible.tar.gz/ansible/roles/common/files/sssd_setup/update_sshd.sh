#!/usr/bin/env bash

# Remove Amazon customized unit file for sshd.
if [ -d "/usr/lib/systemd/system/ssh.service.d/" ]; then
  rm -fr /usr/lib/systemd/system/ssh.service.d/
  systemctl daemon-reload
fi

# Remove any existing setting.
sed -i '/^AuthorizedKeysCommand /d' /etc/ssh/sshd_config
sed -i '/^AuthorizedKeysCommandUser /d' /etc/ssh/sshd_config

# Delete lines starting from '# Arena customize config' till the last line
sed -i '/^#\s\+Arena\s\+customize\s\+config/,$d' /etc/ssh/sshd_config

# Append Arena customize sshd config to sshd_config
cat /tmp/arena-customize-sshd-config.txt >> /etc/ssh/sshd_config

systemctl restart sshd

# Disable password auth from PAM
sed -i '/auth\s\+substack\s\+password-auth/d' /etc/pam.d/sshd